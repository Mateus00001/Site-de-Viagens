# Importa as bibliotecas necessárias
from flask import Flask, render_template, request
import requests

# Inicia o objeto Flask
app = Flask(__name__)

# Define a classe ConversorClass
class ConversorClass:
    """
    Classe que representa um conversor de moedas.
    """

    # Define o construtor da classe
    def __init__(self):
        """
        Construtor da classe.
        """
        # Define a URL da API de conversão de moedas
        self._url = 'https://api.exchangerate-api.com/v4/latest/BRL'
        # Inicializa uma lista vazia para as moedas disponíveis
        self._currencies = []
        # Inicializa um dicionário vazio para as taxas de câmbio
        self._exchange_rates = {}
        # Adiciona as moedas que deseja converter
        self._load_currencies()

    # Define o método _load_currencies
    def _load_currencies(self):
        """
        Carrega as moedas disponíveis na API.
        """
        # Faz uma requisição GET para a API e salva os dados em formato JSON
        data = requests.get(self._url).json()
        # Extrai as moedas disponíveis e adiciona na lista de moedas
        self._currencies = list(data['rates'].keys())
        # Adiciona a moeda BRL à lista de moedas
        self._currencies.append('BRL')
        # Ordena a lista de moedas em ordem alfabética
        self._currencies = sorted(self._currencies)

    # Define o método _convert
    def _convert(self, amount, from_currency, to_currency):
        """
        Converte o valor de uma moeda para outra.
        """
        # Faz uma requisição GET para a API e salva os dados em formato JSON
        data = requests.get(self._url).json()
        # Extrai as taxas de câmbio e adiciona no dicionário de taxas de câmbio
        self._exchange_rates = {currency: float(rate) for currency, rate in data['rates'].items()}

        # Se a moeda de origem não for BRL, converte o valor para BRL
        if from_currency != 'BRL':
            amount = amount / self._exchange_rates[from_currency]

        # limita a quantidade de decimais para 2
        amount = round(float(amount) * self._exchange_rates[to_currency], 2)

        # Retorna o valor convertido
        return amount


if __name__ == '__main__':
    app.run(debug=True)

