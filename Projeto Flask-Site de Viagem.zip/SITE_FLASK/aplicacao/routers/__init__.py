from aplicacao import app, database, bcrypt
from flask import redirect, render_template, url_for, flash,request
from aplicacao.forms import FormLogin, FormCadastrarUsuario
from aplicacao.models import Usuario
from flask_login import login_user, logout_user,login_required
from aplicacao.converter import ConversorClass
from flask import Flask, render_template, request, send_file
from fpdf import FPDF
from datetime import datetime, timedelta
import os



@app.route('/', methods=['GET', 'POST'])
def login():
    form = FormLogin()
    if form.validate_on_submit():
        user = Usuario.query.filter_by(usuario=form.usuario.data).first()
        if user and bcrypt.check_password_hash(user.senha, form.senha.data ):
            login_user(user, remember=form.lembrar.data)
            flash(f'login feito {form.usuario.data}', 'alert alert-success')
            return render_template('index.html')
        else:
            flash(f'Usuario ou senha errados', 'alert alert-danger')
    return render_template('login.html', form=form)


@app.route("/")
def index():
    return render_template('index.html')
# Define a rota principal
@app.route('/converter', methods=['GET', 'POST'])
def conver():
    # Se a requisição for POST (ou seja, o formulário foi submetido)
    # if request.method == 'POST':

    # Instancia um objeto da classe ConversorClass
    conversor = ConversorClass()
    # Inicializa a variável result como uma string vazia
    result = ''
    # Extrai o valor a ser convertido, a moeda de origem e a moeda de destino do formulário
    amount = request.form.get('valor')
    from_currency = request.form.get('moedaOrigem')
    to_currency = request.form.get('moedaDestino')

        # Converte o valor usando o método _convert da classe ConversorClass
    if amount and from_currency and to_currency:
        result = conversor._convert(amount, from_currency, to_currency)
        print(result)
        # Renderiza o template index.html passando o resultado da conversão como argumento
        return render_template('conver.html', result=result)
    return render_template('conver.html')


@app.route('/pacote', methods=['GET', 'POST'])
def orcar():
    if request.method == 'POST':
        # obter dados do formulário
        destino = request.form['destino']
        classe_aviao = request.form['classe_aviao']
        hotel = request.form['hotel']

        # calcular preço total com base nas escolhas do usuário
        preco_base = 0
        if destino == 'Tokyo':
            preco_base += 1500
        elif destino == 'Soul':
            preco_base += 1200
        elif destino == 'Roma':
            preco_base += 1000
        elif destino == 'Madri':
            preco_base += 900

        if classe_aviao == 'economica':
            preco_base += 500
        elif classe_aviao == 'executiva':
            preco_base += 1500
        elif classe_aviao == 'primeira_classe':
            preco_base += 3000

        if hotel == '3_estrelas':
            preco_base += 200
        elif hotel == '4_estrelas':
            preco_base += 400
        elif hotel == '5_estrelas':
            preco_base += 800

        preco_total = preco_base * 1.15  # incluir 15% de impostos

        return render_template('resultado.html', preco_total=preco_total)
    else:
        return render_template('pac.html')

@app.route("/SOUL")
def SOUL():
    return render_template('SOUL.html')

@app.route("/Madri")
def Madri():
    return render_template('Madri.html')


@app.route("/TOKYO")
def TOKYO():
    return render_template('TOKYO.html')


@app.route("/ROMA")
def ROMA():
    return render_template('ROMA.html')

@app.route('/sair')
@login_required
def sair():
    logout_user()
    flash(f'Sessão encerrada', 'alert alert-info')
    return redirect(url_for('login'))


@app.route('/cadastro-usuario', methods=['GET', 'POST'])
@login_required
def cadastro_usuario():
    form = FormCadastrarUsuario()
    if form.validate_on_submit():
        senha_crypto = bcrypt.generate_password_hash(form.senha.data)
        print(f'senha{form.usuario.data}')
        print(f'senha cripitografada{senha_crypto}')
        user = Usuario(usuario=form.usuario.data, email=form.email.data, senha=form.senha.data)
        database.session.add(user)
        database.session.commit()
        return redirect('/')
    return render_template('cadastrar_usuario.html', form=form)



