class pessoa :
    def __init__(self, nome):
        self.nome = nome


    def exibir_nome(self):
        print(f'')