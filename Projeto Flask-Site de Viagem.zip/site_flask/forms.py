from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, BooleanField
from wtforms.validators import DataRequired, length

class FormLogin(FlaskForm):
    usuario = StringField('Usuário', validators=[DataRequired(), length(6,12)])
    senha = PasswordField('Senha')
    lembrar = BooleanField('Lembrar-se')
    submit_entrar = SubmitField('Entrar')



class FormCadastrarUsuario(FlaskForm):
    usuario = StringField('Nome de Usuário')
    email = StringField('E-mail')
    senha = PasswordField('Senha')
    comfirmacao = PasswordField('Confirmação de Senha')
    submit_criar = SubmitField('Criar')